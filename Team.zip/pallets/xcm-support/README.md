# XCM Support Module.

## Overview

The XCM support module provides supporting traits, types and implementations,
to support cross-chain message(XCM) integration with ORML modules.
